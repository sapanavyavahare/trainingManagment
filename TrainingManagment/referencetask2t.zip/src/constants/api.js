module.exports = {
    API: "/api/v1.0",
    TRAINERS: "/trainers",
  };