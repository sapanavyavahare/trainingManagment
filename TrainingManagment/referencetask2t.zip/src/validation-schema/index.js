module.exports = {
  TrainerSchema: require('./TrainerSchema'),
};
