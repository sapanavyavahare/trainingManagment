module.exports = {
    TrainerService: require('./trainerService'),
};
