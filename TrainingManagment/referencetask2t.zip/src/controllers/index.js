module.exports = {
    TrainerController: require('./trainerConn'),
};
